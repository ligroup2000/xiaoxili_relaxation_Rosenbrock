function [Gamma,tmesh]=RERK4(tau)

w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
   w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
   w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
   w1+w5 w11+w3+w44 w11+w3-w44 w1];
b=[2*w1 2*w11 2*w11 2*w1];
c=[0.5-w2; 0.5-w22; 0.5+w22; 0.5+w2];

alpha=1;  beta=2*3*3;
left=-15;  right=15;  N=1000;  h=(right-left)/N;  xmesh=(left:h:right-h)';
K=spdiags((-490/180)*ones(N,1),0,N,N)+ ... 
  spdiags((270/180)*ones(N,1),-1,N,N)+ ...
  spdiags((270/180)*ones(N,1),1,N,N)+ ...
  spdiags((-27/180)*ones(N,1),-2,N,N)+ ...
  spdiags((-27/180)*ones(N,1),2,N,N)+ ...
  spdiags((2/180)*ones(N,1),-3,N,N)+ ...
  spdiags((2/180)*ones(N,1),3,N,N)+ ...
  spdiags((2/180)*ones(N,1),N-3,N,N)+ ...
  spdiags((2/180)*ones(N,1),3-N,N,N)+ ...
  spdiags((-27/180)*ones(N,1),N-2,N,N)+ ...
  spdiags((-27/180)*ones(N,1),2-N,N,N)+ ...
  spdiags((270/180)*ones(N,1),N-1,N,N)+ ...
  spdiags((270/180)*ones(N,1),1-N,N,N);  K=(1/h/h)*K;
oNN=sparse(N,N);  AA=[oNN alpha*K;-alpha*K oNN]; 
func_F=@(svu)0.5*beta*(svu.^2);  func_f=@(svu)beta*svu; 
func_fv=@(svu,u)beta*(svu.*u);  func_fu=@(svu,v)-beta*(svu.*v);
s=size(A,1);  Matrix=speye(2*N*s)-tau*kron(A,AA);  es=ones(s,1);

t=0;  psin=sech(xmesh);  Vn=imag(psin);  Un=real(psin);  Xn=[Vn;Un];  
Gamma=[];  tmesh=t;

Iter_err=1;  ccout=0;  Xmid=kron(es,Xn); 
while (Iter_err > 10^(-14) && ccout < 100)
    Xmid_c=reshape(Xmid,2*N,s);  Vmid_c=Xmid_c(1:N,:);  Umid_c=Xmid_c(N+1:end,:);  sVUmid_c=Vmid_c.^2+Umid_c.^2;
    Fmid_c=[func_fv(sVUmid_c,Umid_c);func_fu(sVUmid_c,Vmid_c)];
    F=Xn+tau*Fmid_c*A';
    Xmid_save=Xmid;  Xmid=Matrix\F(:);
    Iter_err=max(abs(Xmid-Xmid_save));
    ccout=ccout+1;
end
Xmid_c=reshape(Xmid,2*N,s);  Vmid_c=Xmid_c(1:N,:);  Umid_c=Xmid_c(N+1:end,:);  sVUmid_c=Vmid_c.^2+Umid_c.^2;
Fmid_c=[func_fv(sVUmid_c,Umid_c);func_fu(sVUmid_c,Vmid_c)];
Update=tau*AA*Xmid_c*b'+tau*Fmid_c*b';  Vn_Update=Update(1:N);  Un_Update=Update(N+1:end);
Update_norm=sum(abs(Vn_Update).^2)+sum(abs(Un_Update).^2);
if ( Update_norm==0 )
    gamma=1;
else
    UpdateUpdate=-h*alpha*(Vn_Update'*K*Vn_Update+Un_Update'*K*Un_Update);
    OldUpdate=-h*alpha*(Vn'*K*Vn_Update+Un'*K*Un_Update);  sVUn=Vn.^2+Un.^2;
    Nolinear_old=-h*sum(func_F(sVUn));
    [gamma,~,~,~]=compute_gamma(Vn,Un,Vn_Update,Un_Update,UpdateUpdate,OldUpdate,h,func_F,Nolinear_old,func_f);
end
Xn=Xn+gamma*Update;  Vn=Xn(1:N);  Un=Xn(N+1:end);
t1=t;
t=t+gamma*tau;
t2=t; 
tmesh=[tmesh t2];  Gamma=[Gamma gamma];
fprintf('t=%d,dis=%d\n',t2,abs(gamma-1));

for k=1:99
    coe=extrapolate_coe(t1,t2,c,tau,tau);  Xmid_e_c=Xmid_c*coe';
    Vmid_e_c=Xmid_e_c(1:N,:);  Umid_e_c=Xmid_e_c(N+1:end,:);  sVUmid_e_c=Vmid_e_c.^2+Umid_e_c.^2;
    Fmid_e_c=[func_fv(sVUmid_e_c,Umid_e_c);func_fu(sVUmid_e_c,Vmid_e_c)];
    F=Xn+tau*Fmid_e_c*A';
    Xmid=Matrix\F(:);  Xmid_c=reshape(Xmid,2*N,s);
    Update=tau*AA*Xmid_c*b'+tau*Fmid_e_c*b';  Vn_Update=Update(1:N);  Un_Update=Update(N+1:end);
    Update_norm=sum(abs(Vn_Update).^2)+sum(abs(Un_Update).^2);
    if ( Update_norm==0 )
        gamma=1;
    else
        UpdateUpdate=-h*alpha*(Vn_Update'*K*Vn_Update+Un_Update'*K*Un_Update);
        OldUpdate=-h*alpha*(Vn'*K*Vn_Update+Un'*K*Un_Update);  sVUn=Vn.^2+Un.^2;
        Nolinear_old=-h*sum(func_F(sVUn));
        [gamma,~,~,~]=compute_gamma(Vn,Un,Vn_Update,Un_Update,UpdateUpdate,OldUpdate,h,func_F,Nolinear_old,func_f);
    end
    Xn=Xn+gamma*Update;  Vn=Xn(1:N);  Un=Xn(N+1:end);
    t1=t;
    t=t+gamma*tau;
    t2=t; 
    tmesh=[tmesh t2];  Gamma=[Gamma gamma];
    fprintf('t=%d,dis=%d\n',t2,abs(gamma-1));
end

plot(Gamma)