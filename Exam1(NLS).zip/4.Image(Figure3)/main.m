[xmesh3,tmesh3,sVUn_save3]=RRB(1/1000,4,3);
[xmesh4,tmesh4,sVUn_save4]=RRB(1/1000,4,4);
[xmesh5,tmesh5,sVUn_save5]=RRB(1/1000,4,5);

save('data.mat','xmesh3','tmesh3','sVUn_save3', ...
                'xmesh4','tmesh4','sVUn_save4', ...
                'xmesh5','tmesh5','sVUn_save5');