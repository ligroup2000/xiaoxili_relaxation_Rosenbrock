function [xmesh,tmesh,sVUn_save]=RRB(tau,p,nn)

if (p==2)
    gamma_coe=0.5;  GAMMA=[gamma_coe 0;-1 gamma_coe];  ALPHA=[0 0;1 0];  B=[0.5 0.5];
    s=size(B,2);  C=diag((1/gamma_coe)*ones(s,1))-GAMMA^(-1);  A=ALPHA/GAMMA;  M=B/GAMMA; 
    aa=1/tau/gamma_coe;  
elseif (p==3)
    gamma_coe=0.78867513459481287;  
    GAMMA=[gamma_coe 0 0;-1.5773502691896257 gamma_coe 0;-0.67075317547305480 -0.17075317547305482 gamma_coe];  
    ALPHA=[0 0 0;1.5773502691896257 0 0;0.5 0 0];  
    B=[0.10566243270259355 0.049038105676657971 0.84529946162074843];
    s=size(B,2);  C=diag((1/gamma_coe)*ones(s,1))-GAMMA^(-1);  A=ALPHA/GAMMA;  M=B/GAMMA; 
    aa=1/tau/gamma_coe;  
elseif (p==4)
    gamma_coe=0.395;
    GAMMA=[gamma_coe 0 0 0; ...
           -0.767672395484 gamma_coe 0 0; ...
           -0.851675323742 0.522967289188 gamma_coe 0; ...
           0.288463109545  0.0880214273381 -0.337389840627 gamma_coe;];  
    ALPHA=[0 0 0 0 ; ...
           0.438 0 0 0 ; ...
           0.796920457938  0.0730795420615 0 0 ; ...
           0.796920457938  0.0730795420615 0 0;];  
    B=[0.199293275701 0.482645235674 0.0680614886256 0.25];
    s=size(B,2);  C=diag((1/gamma_coe)*ones(s,1))-GAMMA^(-1);  A=ALPHA/GAMMA;  M=B/GAMMA; 
    aa=1/tau/gamma_coe; 
end

T=3;  alpha=1;  beta=2*nn*nn;
left=-15;  right=15;  N=1000;  h=(right-left)/N;  xmesh=(left:h:right-h)';
K=spdiags((-490/180)*ones(N,1),0,N,N)+ ... 
  spdiags((270/180)*ones(N,1),-1,N,N)+ ...
  spdiags((270/180)*ones(N,1),1,N,N)+ ...
  spdiags((-27/180)*ones(N,1),-2,N,N)+ ...
  spdiags((-27/180)*ones(N,1),2,N,N)+ ...
  spdiags((2/180)*ones(N,1),-3,N,N)+ ...
  spdiags((2/180)*ones(N,1),3,N,N)+ ...
  spdiags((2/180)*ones(N,1),N-3,N,N)+ ...
  spdiags((2/180)*ones(N,1),3-N,N,N)+ ...
  spdiags((-27/180)*ones(N,1),N-2,N,N)+ ...
  spdiags((-27/180)*ones(N,1),2-N,N,N)+ ...
  spdiags((270/180)*ones(N,1),N-1,N,N)+ ...
  spdiags((270/180)*ones(N,1),1-N,N,N);  K=(1/h/h)*K;
aaI2d=aa*speye(2*N);  oNN=sparse(N,N);  AA=[oNN alpha*K;-alpha*K oNN]; 
func_F=@(svu)0.5*beta*(svu.^2);  func_f=@(svu)beta*svu; 
func_fv=@(svu,u)beta*(svu.*u);  func_fu=@(svu,v)-beta*(svu.*v);
func_fv_der_v=@(v,u)2*beta*(v.*u);  func_fv_der_u=@(svu,v,u)2*beta*(u.^2)+beta*svu;
func_fu_der_v=@(svu,v,u)-2*beta*(v.^2)-beta*svu;  func_fu_der_u=@(v,u)-2*beta*(u.*v);

tn=0;  psin=sech(xmesh);  Vn=imag(psin);  Un=real(psin);  sVUn=Vn.^2+Un.^2;  sVUn_save=sVUn; 
sVUn_save=sVUn;  tmesh=tn;   
VU_intro=zeros(2*N,s);
while (tn<(T-tau))  
    Matrix=aaI2d-AA-[spdiags(func_fv_der_v(Vn,Un),0,N,N) spdiags(func_fv_der_u(sVUn,Vn,Un),0,N,N); ...
                     spdiags(func_fu_der_v(sVUn,Vn,Un),0,N,N) spdiags(func_fu_der_u(Vn,Un),0,N,N)];
    VU_intro(:,1)=Matrix\[alpha*K*Un+func_fv(sVUn,Un);-alpha*K*Vn+func_fu(sVUn,Vn)];
    for kk=2:s
        VUmid=[Vn;Un]+VU_intro(:,1:kk-1)*(A(kk,1:kk-1))';
        Vmid=VUmid(1:N);  Umid=VUmid(N+1:end);  sVUmid=Vmid.^2+Umid.^2;
        VU_intro(:,kk)=Matrix\([alpha*K*Umid+func_fv(sVUmid,Umid);-alpha*K*Vmid+func_fu(sVUmid,Vmid)]+(1/tau)*VU_intro(:,1:kk-1)*(C(kk,1:kk-1)'));
    end
    dn=VU_intro*M';  Vn_Update=dn(1:N);  Un_Update=dn(N+1:end); 
    Update_norm=sum(abs(Vn_Update).^2)+sum(abs(Un_Update).^2);
    if ( Update_norm==0 )
        gamma=1;
    else
        UpdateUpdate=-h*alpha*(Vn_Update'*K*Vn_Update+Un_Update'*K*Un_Update);
        OldUpdate=-h*alpha*(Vn'*K*Vn_Update+Un'*K*Un_Update);
        Nolinear_old=-h*sum(func_F(sVUn));
        [gamma,~,~,~]=compute_gamma(Vn,Un,Vn_Update,Un_Update,UpdateUpdate,OldUpdate,h,func_F,Nolinear_old,func_f);
    end
    Vn=Vn+gamma*Vn_Update;  Un=Un+gamma*Un_Update;  sVUn=Vn.^2+Un.^2;  tn=tn+gamma*tau;
    sVUn_save=[sVUn_save sVUn];  tmesh=[tmesh tn]; 
end

% [X,Y]=meshgrid(tmesh,xmesh); surf(X,Y,sqrt(sVUn_save));  shading interp;