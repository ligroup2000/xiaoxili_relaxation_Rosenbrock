1. Run "main.m" directly, and the code gives "Initial1.mat";
2. Put "Initial1.mat" into the folder "figure", and run  "plot_image.m" to get the corresponding figures.