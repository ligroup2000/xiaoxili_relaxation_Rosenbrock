[Un_save,tn_save,XMESH,YMESH]=RRB_initial1(1/10,4);
save('Initial1.mat','Un_save','tn_save','XMESH','YMESH');