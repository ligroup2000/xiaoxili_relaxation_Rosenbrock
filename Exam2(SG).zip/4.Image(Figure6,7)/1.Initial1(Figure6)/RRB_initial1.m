function [Un_save,tn_save,XMESH,YMESH]=RRB_initial1(tau,p)

if (p==2)
    gamma_coe=0.5;  GAMMA=[gamma_coe 0;-1 gamma_coe];  ALPHA=[0 0;1 0];  B=[0.5 0.5];
    s=size(B,2);  C=diag((1/gamma_coe)*ones(s,1))-GAMMA^(-1);  A=ALPHA/GAMMA;  M=B/GAMMA; 
    aa=1/tau/gamma_coe;
elseif (p==3)
    gamma_coe=0.78867513459481287;  
    GAMMA=[gamma_coe 0 0;-1.5773502691896257 gamma_coe 0;-0.67075317547305480 -0.17075317547305482 gamma_coe];  
    ALPHA=[0 0 0;1.5773502691896257 0 0;0.5 0 0];  
    B=[0.10566243270259355 0.049038105676657971 0.84529946162074843];
    s=size(B,2);  C=diag((1/gamma_coe)*ones(s,1))-GAMMA^(-1);  A=ALPHA/GAMMA;  M=B/GAMMA; 
    aa=1/tau/gamma_coe; 
elseif (p==4)
    gamma_coe=0.395;
    GAMMA=[gamma_coe 0 0 0; ...
           -0.767672395484 gamma_coe 0 0; ...
           -0.851675323742 0.522967289188 gamma_coe 0; ...
           0.288463109545  0.0880214273381 -0.337389840627 gamma_coe;];  
    ALPHA=[0 0 0 0 ; ...
           0.438 0 0 0 ; ...
           0.796920457938  0.0730795420615 0 0 ; ...
           0.796920457938  0.0730795420615 0 0;];  
    B=[0.199293275701 0.482645235674 0.0680614886256 0.25];
    s=size(B,2);  C=diag((1/gamma_coe)*ones(s,1))-GAMMA^(-1);  A=ALPHA/GAMMA;  M=B/GAMMA; 
    aa=1/tau/gamma_coe;
end

T=16;  
left=-14;  right=14;  Nx=560;  hx=(right-left)/Nx; 
bottom=-14;  top=14;  Ny=560;  hy=(top-bottom)/Ny;
xmesh=left+0.5*hx:hx:right-0.5*hx;  ymesh=bottom+0.5*hy:hy:top-0.5*hy;  [XMESH,YMESH]=meshgrid(xmesh,ymesh); 
KKx=spdiags(ones(Nx,1),1,Nx,Nx)+spdiags(ones(Nx,1),-1,Nx,Nx);  
KKy=spdiags(ones(Ny,1),1,Ny,Ny)+spdiags(ones(Ny,1),-1,Ny,Ny);
K=kron(KKx,speye(Ny))+kron(speye(Nx),KKy);  
d=size(K,2);  K=K+(-1)*spdiags(sum(K,2),0,d,d);  K=(1/hx/hy)*K;  
Id=speye(d);  aaI2d=aa*speye(2*d);  odd=sparse(d,d);  AA=[odd K;Id odd];
alpha=1;  func_F=@(x)alpha*(-cos(x));  func_f=@(x)alpha*(sin(x));  func_f_der=@(x)alpha*(cos(x));

tn=0;  
Un_temp=4*atan(exp(3-sqrt(XMESH.^2+YMESH.^2)));
Vn_temp=zeros(Ny,Nx);
Vn=Vn_temp(:);  Un=Un_temp(:);  Un_save=Un;  tn_save=tn;
Energy=0.5*hx*hy*(Vn'*Vn-Un'*K*Un)+hx*hy*sum(func_F(Un));  tmesh=tn;
VU_intro=zeros(2*d,s);  
while (tn<(T-tau))  
    Matrix=aaI2d-AA-[odd -spdiags(func_f_der(Un),0,d,d);odd odd];
    VU_intro(:,1)=Matrix\[K*Un-func_f(Un);Vn];
    for kk=2:s
        VU_mid=[Vn;Un]+VU_intro(:,1:kk-1)*(A(kk,1:kk-1))';
        V_mid=VU_mid(1:d);  U_mid=VU_mid(d+1:end);
        VU_intro(:,kk)=Matrix\([K*U_mid-func_f(U_mid);V_mid]+(1/tau)*VU_intro(:,1:kk-1)*(C(kk,1:kk-1)'));
    end
    dn_t=VU_intro*M';  Vn_Update=dn_t(1:d);  Un_Update=dn_t(d+1:end);  
    Update_norm=sum(abs(Vn_Update).^2)+sum(abs(Un_Update).^2);
    if ( Update_norm==0 )
        gamma=1;
    else
        UpdateUpdate=0.5*hx*hy*(Vn_Update'*Vn_Update-Un_Update'*K*Un_Update);
        OldUpdate=0.5*hx*hy*(Vn'*Vn_Update-Un'*K*Un_Update);
        Nolinear_old=hx*hy*sum(func_F(Un));
        [gamma,~]=compute_gamma(Un,Un_Update,UpdateUpdate,OldUpdate,hx,hy,func_F,Nolinear_old,func_f);
    end
    Vn=Vn+gamma*Vn_Update;  Un=Un+gamma*Un_Update;  tn=tn+gamma*tau;
    if ( (abs(tn-4)<(2*tau)) ||  (abs(tn-8)<(2*tau)) || (abs(tn-11.5)<(2*tau)) || (abs(tn-13)<(2*tau)) || (abs(tn-15)<(2*tau)))
        Un_save=[Un_save Un];  tn_save=[tn_save tn];
    end
    Energy=[Energy 0.5*hx*hy*(Vn'*Vn-Un'*K*Un)+hx*hy*sum(func_F(Un))];  tmesh=[tmesh tn];
end