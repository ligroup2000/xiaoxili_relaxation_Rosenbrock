%% INPUT TIGHTPLOT PARAMETERS
TightPlot.ColumeNumber = 1;     % ��ͼ����
TightPlot.RowNumber = 1;    % ��ͼ����
TightPlot.GapW = 0.05;  % ��ͼ֮������Ҽ��
TightPlot.GapH = 0.05;   % ��ͼ֮������¼��
TightPlot.MarginsLower = 0.16;   % ��ͼ��ͼƬ�·��ļ��
TightPlot.MarginsUpper = 0.13;  % ��ͼ��ͼƬ�Ϸ��ļ��
TightPlot.MarginsLeft = 0.2;   % ��ͼ��ͼƬ�󷽵ļ��
TightPlot.MarginsRight = 0.25;  % ��ͼ��ͼƬ�ҷ��ļ��

%% PLOT
figure(1);  % ����Figure
p = tight_subplot(TightPlot.ColumeNumber,TightPlot.RowNumber,...
    [TightPlot.GapH TightPlot.GapW],...
    [TightPlot.MarginsLower TightPlot.MarginsUpper],...
    [TightPlot.MarginsLeft TightPlot.MarginsRight]);    % �������ò�����һ���Ѿ�������

load RERB2.mat 
ERR_RERB2=ERR(4:end);  TIME_RERB2=TIME(4:end);
load RRB2.mat 
ERR_RRB2=ERR(4:end);  TIME_RRB2=TIME(4:end);
load RERB3.mat
ERR_RERB3=ERR(4:end);  TIME_RERB3=TIME(4:end);
load RRB3.mat
ERR_RRB3=ERR(4:end);  TIME_RRB3=TIME(4:end);
load RERB4.mat
ERR_RERB4=ERR(4:end);  TIME_RERB4=TIME(4:end);
load RRB4.mat
ERR_RRB4=ERR(4:end);  TIME_RRB4=TIME(4:end);

loglog(TIME_RERB2,ERR_RERB2,'--bD','LineWidth',2,'MarkerSize',12);  hold on;
loglog(TIME_RERB3,ERR_RERB3,'--go','LineWidth',2,'MarkerSize',12);
loglog(TIME_RERB4,ERR_RERB4,'--rs','LineWidth',2,'MarkerSize',12);
loglog(TIME_RRB2,ERR_RRB2,'-bD','LineWidth',2,'MarkerSize',12,'Markerfacecolor','b'); 
loglog(TIME_RRB3,ERR_RRB3,'-go','LineWidth',2,'MarkerSize',12,'Markerfacecolor','g');  
loglog(TIME_RRB4,ERR_RRB4,'-rs','LineWidth',2,'MarkerSize',12,'Markerfacecolor','r');

set(gca,'XLim',[0.6 2500])
set(gca,'YLim',[10^(-10) 10^(1)])
set(gca,'linewidth',2,'FontSize',24)
xlabel('CPU time','interpreter','latex','FontSize',32)
ylabel('$Err$','interpreter','latex','FontSize',32)
legend('RERB2','RERB3','RERB4','RRB2','RRB3','RRB4')
set(legend,'interpreter','latex','location','southwest','FontSize',20) 