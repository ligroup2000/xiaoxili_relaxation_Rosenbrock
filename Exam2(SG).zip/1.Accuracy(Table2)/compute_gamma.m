function [gamma,iter_count,iter_err,vector]=compute_gamma(Un,Un_Update,UpdateUpdate,OldUpdate,h,func_F,Nolinear_old,func_f)

iter_err=1;  iter_count=0;  gamma=1;
while ((iter_err>10^(-14)) && (iter_count<5))
    Un1=Un+gamma*Un_Update;
    vector=gamma^2*UpdateUpdate+2*gamma*OldUpdate+h*h*sum(func_F(Un1))-Nolinear_old;
    matrix=2*gamma*UpdateUpdate+2*OldUpdate+h*h*sum(func_f(Un1).*Un_Update);
    gamma_save=gamma;  gamma=gamma-matrix\vector;
    iter_err=abs(gamma_save-gamma);  iter_count=iter_count+1;
end