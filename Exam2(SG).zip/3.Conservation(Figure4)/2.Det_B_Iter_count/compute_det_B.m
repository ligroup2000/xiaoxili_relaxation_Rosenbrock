function result=compute_det_B(Vn,Un,p)

left=-7;  right=7;  N=40;  h=(right-left)/N;  
KK=spdiags(ones(N,1),1,N,N)+spdiags(ones(N,1),-1,N,N);  K=kron(KK,speye(N))+kron(speye(N),KK);  
d=size(K,2);  K=K+(-1)*spdiags(sum(K,2),0,d,d);  K=(1/h/h)*K;  
Id=speye(d);  odd=sparse(d,d);  AA=[odd K;Id odd];
alpha=100;  func_f=@(x)alpha*(sin(x));  func_f_der=@(x)alpha*(cos(x));

if (p==2)
    gamma_coe=0.5;  GAMMA=[gamma_coe 0;-1 gamma_coe];  ALPHA=[0 0;1 0];  B=[0.5 0.5];
    s=size(B,2);  C=diag((1/gamma_coe)*ones(s,1))-GAMMA^(-1);  A=ALPHA/GAMMA;  M=B/GAMMA; 
elseif (p==3)
    gamma_coe=0.78867513459481287;  
    GAMMA=[gamma_coe 0 0;-1.5773502691896257 gamma_coe 0;-0.67075317547305480 -0.17075317547305482 gamma_coe];  
    ALPHA=[0 0 0;1.5773502691896257 0 0;0.5 0 0];  
    B=[0.10566243270259355 0.049038105676657971 0.84529946162074843];
    s=size(B,2);  C=diag((1/gamma_coe)*ones(s,1))-GAMMA^(-1);  A=ALPHA/GAMMA;  M=B/GAMMA; 
elseif (p==4)
    gamma_coe=0.395;
    GAMMA=[gamma_coe 0 0 0; ...
           -0.767672395484 gamma_coe 0 0; ...
           -0.851675323742 0.522967289188 gamma_coe 0; ...
           0.288463109545  0.0880214273381 -0.337389840627 gamma_coe;];  
    ALPHA=[0 0 0 0 ; ...
           0.438 0 0 0 ; ...
           0.796920457938  0.0730795420615 0 0 ; ...
           0.796920457938  0.0730795420615 0 0;];  
    B=[0.199293275701 0.482645235674 0.0680614886256 0.25];
    s=size(B,2);  C=diag((1/gamma_coe)*ones(s,1))-GAMMA^(-1);  A=ALPHA/GAMMA;  M=B/GAMMA; 
end

tau=10^(-4);  aa=1/tau/gamma_coe;  aaI2d=aa*speye(2*d);

VU_intro=zeros(2*d,s);
Matrix=aaI2d-AA-[odd -spdiags(func_f_der(Un),0,d,d);odd odd];
VU_intro(:,1)=Matrix\[K*Un-func_f(Un);Vn];
for kk=2:s
    VU_mid=[Vn;Un]+VU_intro(:,1:kk-1)*(A(kk,1:kk-1))';
    V_mid=VU_mid(1:d);  U_mid=VU_mid(d+1:end);
    VU_intro(:,kk)=Matrix\([K*U_mid-func_f(U_mid);V_mid]+(1/tau)*VU_intro(:,1:kk-1)*(C(kk,1:kk-1)'));
end
dn_t=VU_intro*M';  Vn_Update=dn_t(1:d);  Un_Update=dn_t(d+1:end);

UpdateUpdate=0.5*h*h*(Vn_Update'*Vn_Update-Un_Update'*K*Un_Update);
OldUpdate=0.5*h*h*(Vn'*Vn_Update-Un'*K*Un_Update);
result=(1/tau/tau)*(2*UpdateUpdate+2*OldUpdate+h*h*sum(func_f(Un+Un_Update).*Un_Update));
    
end