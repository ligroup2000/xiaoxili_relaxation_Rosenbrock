function [coe1,coe2,coe3,AA1,AA2,AA3,AA4,AA5,BB1,BB2,BB3,BB4,BB5,e5,e6]=generate_coefficient(tau,A)

p1=-0.9061798459386640;  p2=-0.5384693101056830;  p3=0;  p4=-p2;  p5=-p1;
GP=[p1 p2 p3 p4 p5];

w1=0.2369268850561890;  w2=0.4786286704993660;  w3=0.5688888888888880;  w4=w2;  w5=w1;  GW=[w1 w2 w3 w4 w5];

GP=(1/2)*(GP+1);  GW=(1/2)*GW;

c1=0;  c2=1/2;  c3=1;
coe1=2*(GP-c2).*(GP-c3);
coe2=(-4)*GP.*(GP-c3);
coe3=2*(GP-c1).*(GP-c2);

V=tau*A;
e1=phipade(-V,1);  e2=phipade(-0.5*V,1);  e3=phipade(0.5*V,1);  e4=phipade(V,1);  e5=expm(0.5*V);  e6=expm(V);
alp=0;
a111=alp;  a112=1-2*alp;  a114=15+2*alp;  a115=-3-alp;
a121=-2*alp;  a122=-2+4*alp;  a124=-22-4*alp;  a125=4+2*alp; 
a211=-alp;  a212=-1+2*alp;  a214=-19-2*alp;  a215=6+alp; 
a221=2*alp;  a222=2-4*alp;  a224=30+4*alp;  a225=-8-2*alp; 
A11=(-1)*a111*e1+(-1/2)*a112*e2+(1/2)*a114*e3+a115*e4;  
A12=(-1)*a121*e1+(-1/2)*a122*e2+(1/2)*a124*e3+a125*e4;  
A21=(-1)*a211*e1+(-1/2)*a212*e2+(1/2)*a214*e3+a215*e4;  
A22=(-1)*a221*e1+(-1/2)*a222*e2+(1/2)*a224*e3+a225*e4;  
A1=(1/2)*A11+(1/4)*A21;  A2=(1/2)*A12+(1/4)*A22;
AA1=A1+GP(1)*A2;  AA1=GW(1)*AA1;
AA2=A1+GP(2)*A2;  AA2=GW(2)*AA2;
AA3=A1+GP(3)*A2;  AA3=GW(3)*AA3;
AA4=A1+GP(4)*A2;  AA4=GW(4)*AA4;
AA5=A1+GP(5)*A2;  AA5=GW(5)*AA5;
B1=3*e4-2*e3;  B2=-4*e4+4*e3;
BB1=B1+GP(1)*B2;  BB1=GW(1)*BB1;
BB2=B1+GP(2)*B2;  BB2=GW(2)*BB2;
BB3=B1+GP(3)*B2;  BB3=GW(3)*BB3;
BB4=B1+GP(4)*B2;  BB4=GW(4)*BB4;
BB5=B1+GP(5)*B2;  BB5=GW(5)*BB5;