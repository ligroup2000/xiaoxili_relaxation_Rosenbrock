function [time,err,energy_err]=csERK4(tau)
tic;  
T=0.5;  alpha=1;  beta=2*3*3;
left=-15;  right=15;  N=1000;  h=(right-left)/N;  xmesh=(left:h:right-h)';
K=spdiags((-490/180)*ones(N,1),0,N,N)+ ... 
  spdiags((270/180)*ones(N,1),-1,N,N)+ ...
  spdiags((270/180)*ones(N,1),1,N,N)+ ...
  spdiags((-27/180)*ones(N,1),-2,N,N)+ ...
  spdiags((-27/180)*ones(N,1),2,N,N)+ ...
  spdiags((2/180)*ones(N,1),-3,N,N)+ ...
  spdiags((2/180)*ones(N,1),3,N,N)+ ...
  spdiags((2/180)*ones(N,1),N-3,N,N)+ ...
  spdiags((2/180)*ones(N,1),3-N,N,N)+ ...
  spdiags((-27/180)*ones(N,1),N-2,N,N)+ ...
  spdiags((-27/180)*ones(N,1),2-N,N,N)+ ...
  spdiags((270/180)*ones(N,1),N-1,N,N)+ ...
  spdiags((270/180)*ones(N,1),1-N,N,N);  K=(1/h/h)*K;
oNN=sparse(N,N);  AA=[oNN alpha*K;-alpha*K oNN];
func_F=@(svu)0.5*beta*(svu.^2);  func_f=@(svu)beta*svu; 
func_fv=@(svu,u)beta*(svu.*u);  func_fu=@(svu,v)-beta*(svu.*v);
func_fv_der_v=@(v,u)2*beta*(v.*u);  func_fv_der_u=@(svu,v,u)2*beta*(u.^2)+beta*svu;
func_fu_der_v=@(svu,v,u)-2*beta*(v.^2)-beta*svu;  func_fu_der_u=@(v,u)-2*beta*(u.*v);
[coe1,coe2,coe3,AA1,AA2,AA3,AA4,AA5,BB1,BB2,BB3,BB4,BB5,e5,e6]=generate_coefficient(tau,AA);
I4N=speye(4*N,4*N);

tn=0;  psin=sech(xmesh);  Vn=imag(psin);  Un=real(psin);  sVUn=Vn.^2+Un.^2; 
Energy=-h*alpha*(Vn'*K*Vn+Un'*K*Un)-h*sum(func_F(sVUn)); 
VUn=[Vn;Un];  VUVUn=[VUn;VUn];  
while (tn<(T-0.5*tau))
    iter_err=1;  iter_count=0;  KK=[e5*VUn;e6*VUn];  VUVUn1=VUVUn;  
    while ((iter_err>10^(-14)) && iter_count < 5)
        VUm=VUVUn1(1:2*N);  VUn1=VUVUn1(2*N+1:end);
        X1=coe1(1)*VUn+coe2(1)*VUm+coe3(1)*VUn1;  
        X2=coe1(2)*VUn+coe2(2)*VUm+coe3(2)*VUn1;
        X3=coe1(3)*VUn+coe2(3)*VUm+coe3(3)*VUn1;  
        X4=coe1(4)*VUn+coe2(4)*VUm+coe3(4)*VUn1;
        X5=coe1(5)*VUn+coe2(5)*VUm+coe3(5)*VUn1;
        V1=X1(1:N); 
        V2=X2(1:N);
        V3=X3(1:N);
        V4=X4(1:N);
        V5=X5(1:N);
        U1=X1(N+1:end); 
        U2=X2(N+1:end);
        U3=X3(N+1:end);
        U4=X4(N+1:end);
        U5=X5(N+1:end);
        sVU1=V1.^2+U1.^2;  
        sVU2=V2.^2+U2.^2;  
        sVU3=V3.^2+U3.^2;  
        sVU4=V4.^2+U4.^2;  
        sVU5=V5.^2+U5.^2;
        F1=[func_fv(sVU1,U1);func_fu(sVU1,V1)];  
        F2=[func_fv(sVU2,U2);func_fu(sVU2,V2)];  
        F3=[func_fv(sVU3,U3);func_fu(sVU3,V3)];
        F4=[func_fv(sVU4,U4);func_fu(sVU4,V4)];
        F5=[func_fv(sVU5,U5);func_fu(sVU5,V5)]; 
        Fm=AA1*F1+AA2*F2+AA3*F3+AA4*F4+AA5*F5;  
        Fn1=BB1*F1+BB2*F2+BB3*F3+BB4*F4+BB5*F5; 
        Vector=VUVUn1-KK-tau*[Fm;Fn1];  
        F1_der=[spdiags(func_fv_der_v(V1,U1),0,N,N) spdiags(func_fv_der_u(sVU1,V1,U1),0,N,N);spdiags(func_fu_der_v(sVU1,V1,U1),0,N,N) spdiags(func_fu_der_u(V1,U1),0,N,N)]; 
        F2_der=[spdiags(func_fv_der_v(V2,U2),0,N,N) spdiags(func_fv_der_u(sVU2,V2,U2),0,N,N);spdiags(func_fu_der_v(sVU2,V2,U2),0,N,N) spdiags(func_fu_der_u(V2,U2),0,N,N)]; 
        F3_der=[spdiags(func_fv_der_v(V3,U3),0,N,N) spdiags(func_fv_der_u(sVU3,V3,U3),0,N,N);spdiags(func_fu_der_v(sVU3,V3,U3),0,N,N) spdiags(func_fu_der_u(V3,U3),0,N,N)]; 
        F4_der=[spdiags(func_fv_der_v(V4,U4),0,N,N) spdiags(func_fv_der_u(sVU4,V4,U4),0,N,N);spdiags(func_fu_der_v(sVU4,V4,U4),0,N,N) spdiags(func_fu_der_u(V4,U4),0,N,N)]; 
        F5_der=[spdiags(func_fv_der_v(V5,U5),0,N,N) spdiags(func_fv_der_u(sVU5,V5,U5),0,N,N);spdiags(func_fu_der_v(sVU5,V5,U5),0,N,N) spdiags(func_fu_der_u(V5,U5),0,N,N)]; 
        Fm_VUm=coe2(1)*AA1*F1_der+coe2(2)*AA2*F2_der+coe2(3)*AA3*F3_der+coe2(4)*AA4*F4_der+coe2(5)*AA5*F5_der;
        Fm_VUn1=coe3(1)*AA1*F1_der+coe3(2)*AA2*F2_der+coe3(3)*AA3*F3_der+coe3(4)*AA4*F4_der+coe3(5)*AA5*F5_der;
        Fn1_VUm=coe2(1)*BB1*F1_der+coe2(2)*BB2*F2_der+coe2(3)*BB3*F3_der+coe2(4)*BB4*F4_der+coe2(5)*BB5*F5_der;
        Fn1_VUn1=coe3(1)*BB1*F1_der+coe3(2)*BB2*F2_der+coe3(3)*BB3*F3_der+coe3(4)*BB4*F4_der+coe3(5)*BB5*F5_der;
        Matrix=I4N-tau*[Fm_VUm Fm_VUn1; Fn1_VUm Fn1_VUn1];
        VUVUn1_save=VUVUn1;  VUVUn1=VUVUn1-Matrix\Vector;
        iter_err=max(abs(VUVUn1_save-VUVUn1));
        iter_count=iter_count+1;
    end
    VUVUn=VUVUn1;  VUn=VUVUn1(2*N+1:end,1);  tn=tn+tau;  
    Vn=VUn(1:N,1);  Un=VUn(N+1:end,1);  sVUn=Vn.^2+Un.^2;  Energy=[Energy -h*alpha*(Vn'*K*Vn+Un'*K*Un)-h*sum(func_F(sVUn))];
end
toc;

time=toc;
load('reference.mat');  
err=max(abs([Vn;Un]-[Vn_r;Un_r]));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));