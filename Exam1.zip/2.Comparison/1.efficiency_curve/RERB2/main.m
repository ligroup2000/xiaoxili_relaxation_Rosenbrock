stepsize=[1/512 1/512 1/512 1/1024 1/2048 1/4096 1/8192 1/16384];


TIME=[];  ERR=[];  ENERGY_ERR=[];
for k=1:size(stepsize,2)
    tau=stepsize(k); 
    [time,err,energy_err]=RERB2(tau);
    TIME=[TIME time];
    ERR=[ERR err]; 
    ENERGY_ERR=[ENERGY_ERR energy_err];
end

Err_Order=log(ERR(1:end-1)./ERR(2:end))./log(stepsize(1:end-1)./stepsize(2:end));

TIME=TIME(3:end);
ERR=ERR(3:end);
ENERGY_ERR=ENERGY_ERR(3:end);
Err_Order=Err_Order(3:end);

save('RERB2.mat','TIME','ERR','ENERGY_ERR','Err_Order');
