function [time,err,energy_err]=RERB4(tau)
tic; 

T=0.5;  alpha=1;  beta=2*3*3;
left=-15;  right=15;  N=1000;  h=(right-left)/N;  xmesh=(left:h:right-h)';
K=spdiags((-490/180)*ones(N,1),0,N,N)+ ... 
  spdiags((270/180)*ones(N,1),-1,N,N)+ ...
  spdiags((270/180)*ones(N,1),1,N,N)+ ...
  spdiags((-27/180)*ones(N,1),-2,N,N)+ ...
  spdiags((-27/180)*ones(N,1),2,N,N)+ ...
  spdiags((2/180)*ones(N,1),-3,N,N)+ ...
  spdiags((2/180)*ones(N,1),3,N,N)+ ...
  spdiags((2/180)*ones(N,1),N-3,N,N)+ ...
  spdiags((2/180)*ones(N,1),3-N,N,N)+ ...
  spdiags((-27/180)*ones(N,1),N-2,N,N)+ ...
  spdiags((-27/180)*ones(N,1),2-N,N,N)+ ...
  spdiags((270/180)*ones(N,1),N-1,N,N)+ ...
  spdiags((270/180)*ones(N,1),1-N,N,N);  K=(1/h/h)*K;
oNN=sparse(N,N);  AA=[oNN alpha*K;-alpha*K oNN]; 
func_F=@(svu)0.5*beta*(svu.^2);  func_f=@(svu)beta*svu; 
func_fv=@(svu,u)beta*(svu.*u);  func_fu=@(svu,v)-beta*(svu.*v);
func_fv_der_v=@(v,u)2*beta*(v.*u);  func_fv_der_u=@(svu,v,u)2*beta*(u.^2)+beta*svu;
func_fu_der_v=@(svu,v,u)-2*beta*(v.^2)-beta*svu;  func_fu_der_u=@(v,u)-2*beta*(u.*v);

tn=0;  psin=sech(xmesh);  Vn=imag(psin);  Un=real(psin);  sVUn=Vn.^2+Un.^2; 
Energy=-h*alpha*(Vn'*K*Vn+Un'*K*Un)-h*sum(func_F(sVUn)); 
while (tn<(T-tau))
    pGpUn=[spdiags(func_fv_der_v(Vn,Un),0,N,N) spdiags(func_fv_der_u(sVUn,Vn,Un),0,N,N); ...
           spdiags(func_fu_der_v(sVUn,Vn,Un),0,N,N) spdiags(func_fu_der_u(Vn,Un),0,N,N)];  Jn=AA+pGpUn;  
    G=[func_fv(sVUn,Un);func_fu(sVUn,Vn)];  F=AA*[Vn;Un]+G;
    Matrix=tau*[(1/2)*Jn (1/2)*F; sparse(1,2*N) 0];
    exp_matrix=expm(Matrix);
    Vm=Vn+exp_matrix(1:N,end);  Um=Un+exp_matrix(N+1:2*N,end);  sVUm=Vm.^2+Um.^2;
    Dn2=([func_fv(sVUm,Um);func_fu(sVUm,Vm)]-G)-pGpUn*([Vm-Vn;Um-Un]);
    Matrix=tau*[Jn Dn2+F; sparse(1,2*N) 0];
    exp_matrix=expm(Matrix);
    Vm=Vn+exp_matrix(1:N,end);  Um=Un+exp_matrix(N+1:2*N,end);  sVUm=Vm.^2+Um.^2;
    Dn3=([func_fv(sVUm,Um);func_fu(sVUm,Vm)]-G)-pGpUn*([Vm-Vn;Um-Un]);
    II=[0 1 0 0;0 0 1 0;0 0 0 1;0 0 0 0];  
    Matrix=tau*[Jn (-48/tau/tau/tau)*Dn2+(12/tau/tau/tau)*Dn3 (16/tau/tau)*Dn2+(-2/tau/tau)*Dn3 sparse(2*N,1) F; sparse(4,2*N) II];  
    exp_matrix=expm(Matrix);
    Vn_Update=exp_matrix(1:N,end);  Un_Update=exp_matrix(N+1:2*N,end);  
    Update_norm=sum(abs(Vn_Update).^2)+sum(abs(Un_Update).^2);
    if ( Update_norm==0 )
        gamma=1;
    else
        UpdateUpdate=-h*alpha*(Vn_Update'*K*Vn_Update+Un_Update'*K*Un_Update);
        OldUpdate=-h*alpha*(Vn'*K*Vn_Update+Un'*K*Un_Update);
        Nolinear_old=-h*sum(func_F(sVUn));
        [gamma,~,~,~]=compute_gamma(Vn,Un,Vn_Update,Un_Update,UpdateUpdate,OldUpdate,h,func_F,Nolinear_old,func_f);
    end
    Vn_save=Vn;  Un_save=Un;  tn_save=tn;
    Vn=Vn+gamma*Vn_Update;  Un=Un+gamma*Un_Update;  sVUn=Vn.^2+Un.^2;  tn=tn+gamma*tau;
    Energy=[Energy -h*alpha*(Vn'*K*Vn+Un'*K*Un)-h*sum(func_F(sVUn))];
end

if ( (T-tn)<=0 )  
    Un=Un_save;  Vn=Vn_save;  tn=tn_save;  tau=T-tn;
else
    tau=T-tn;
end
pGpUn=[spdiags(func_fv_der_v(Vn,Un),0,N,N) spdiags(func_fv_der_u(sVUn,Vn,Un),0,N,N); ...
       spdiags(func_fu_der_v(sVUn,Vn,Un),0,N,N) spdiags(func_fu_der_u(Vn,Un),0,N,N)];  Jn=AA+pGpUn;  
G=[func_fv(sVUn,Un);func_fu(sVUn,Vn)];  F=AA*[Vn;Un]+G;
Matrix=tau*[(1/2)*Jn (1/2)*F; sparse(1,2*N) 0];
exp_matrix=expm(Matrix);
Vm=Vn+exp_matrix(1:N,end);  Um=Un+exp_matrix(N+1:2*N,end);  sVUm=Vm.^2+Um.^2;
Dn2=([func_fv(sVUm,Um);func_fu(sVUm,Vm)]-G)-pGpUn*([Vm-Vn;Um-Un]);
Matrix=tau*[Jn Dn2+F; sparse(1,2*N) 0];
exp_matrix=expm(Matrix);
Vm=Vn+exp_matrix(1:N,end);  Um=Un+exp_matrix(N+1:2*N,end);  sVUm=Vm.^2+Um.^2;
Dn3=([func_fv(sVUm,Um);func_fu(sVUm,Vm)]-G)-pGpUn*([Vm-Vn;Um-Un]);
II=[0 1 0 0;0 0 1 0;0 0 0 1;0 0 0 0];  
Matrix=tau*[Jn (-48/tau/tau/tau)*Dn2+(12/tau/tau/tau)*Dn3 (16/tau/tau)*Dn2+(-2/tau/tau)*Dn3 sparse(2*N,1) F; sparse(4,2*N) II];  
exp_matrix=expm(Matrix);
Vn=Vn+exp_matrix(1:N,end);  Un=Un+exp_matrix(N+1:2*N,end);  tn=tn+tau;
toc;

time=toc;
load('reference.mat');  
err=max(abs([Vn;Un]-[Vn_r;Un_r]));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));