stepsize=[1/80 1/80 1/80 1/160 1/320 1/640 1/1280 1/2560]; 

TIME=[];  ERR=[];  ENERGY_ERR=[];
for k=1:size(stepsize,2)
    tau=stepsize(k); 
    [time,err,energy_err]=csRK4(tau);
    TIME=[TIME time];
    ERR=[ERR err]; 
    ENERGY_ERR=[ENERGY_ERR energy_err];
end

Err_Order=log(ERR(1:end-1)./ERR(2:end))./log(stepsize(1:end-1)./stepsize(2:end));

TIME=TIME(3:end);
ERR=ERR(3:end);
ENERGY_ERR=ENERGY_ERR(3:end);
Err_Order=Err_Order(3:end);

save('csRK4.mat','TIME','ERR','ENERGY_ERR','Err_Order');
