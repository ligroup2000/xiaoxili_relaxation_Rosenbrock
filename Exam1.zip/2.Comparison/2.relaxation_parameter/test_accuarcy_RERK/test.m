stepsize=[1/640 1/1280 1/2560 1/5120 1/10240];

ERR=[];  GAMMA=[];
for k=1:size(stepsize,2)
    [err,gamma_ave]=RERK(stepsize(k));
    ERR=[ERR err];
    GAMMA=[GAMMA gamma_ave];
end

ERR
ERR_order=log(ERR(1:end-1)./ERR(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
GAMMA
GAMMA_order=log(GAMMA(1:end-1)./GAMMA(2:end))./log(stepsize(1:end-1)./stepsize(2:end))