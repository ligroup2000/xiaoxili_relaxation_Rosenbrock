w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
   w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
   w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
   w1+w5 w11+w3+w44 w11+w3-w44 w1];
b=[2*w1 2*w11 2*w11 2*w1];

alpha=1;  beta=2*3*3;
T=0.5;  tau=1/1000; 
left=-15;  right=15;  N=1000;  h=(right-left)/N;  xmesh=(left:h:right-h)';
K=spdiags((-490/180)*ones(N,1),0,N,N)+ ... 
  spdiags((270/180)*ones(N,1),-1,N,N)+ ...
  spdiags((270/180)*ones(N,1),1,N,N)+ ...
  spdiags((-27/180)*ones(N,1),-2,N,N)+ ...
  spdiags((-27/180)*ones(N,1),2,N,N)+ ...
  spdiags((2/180)*ones(N,1),-3,N,N)+ ...
  spdiags((2/180)*ones(N,1),3,N,N)+ ...
  spdiags((2/180)*ones(N,1),N-3,N,N)+ ...
  spdiags((2/180)*ones(N,1),3-N,N,N)+ ...
  spdiags((-27/180)*ones(N,1),N-2,N,N)+ ...
  spdiags((-27/180)*ones(N,1),2-N,N,N)+ ...
  spdiags((270/180)*ones(N,1),N-1,N,N)+ ...
  spdiags((270/180)*ones(N,1),1-N,N,N);  K=(1/h/h)*K;
L=[sparse(N,N) alpha*K;-alpha*K sparse(N,N)];  
s=size(A,1);  es=ones(s,1); 
Matrix=speye(2*N*s)-tau*kron(A,L);
func_fv=@(svu,u)beta*(svu.*u);  func_fu=@(svu,v)-beta*(svu.*v);
tn=0;  psin=sech(xmesh);  Vn=imag(psin);  Un=real(psin);  VUn=[Vn;Un];

ITER_ERR=[];  ITER_COUNT=[];
for k=1:round(T/tau)
    Iter_err=1;  Iter_count=0;  VUmid=kron(es,VUn);
    while (Iter_err > 10^(-14) && Iter_count < 100)
        VUmid_c=reshape(VUmid,2*N,s);  Vmid_c=VUmid_c(1:N,:);  Umid_c=VUmid_c(N+1:end,:);  sVUmid_c=Vmid_c.^2+Umid_c.^2; 
        Fmid_c=[func_fv(sVUmid_c,Umid_c);func_fu(sVUmid_c,Vmid_c)];
        F=VUn+tau*Fmid_c*A';
        VUmid_save=VUmid;  VUmid=Matrix\F(:);
        Iter_err=max(abs(VUmid-VUmid_save));
        Iter_count=Iter_count+1;
    end
    ITER_ERR=[ITER_ERR Iter_err];  ITER_COUNT=[ITER_COUNT Iter_count];
    VUmid_c=reshape(VUmid,2*N,s);  Vmid_c=VUmid_c(1:N,:);  Umid_c=VUmid_c(N+1:end,:);  sVUmid_c=Vmid_c.^2+Umid_c.^2; 
    Fmid_c=[func_fv(sVUmid_c,Umid_c);func_fu(sVUmid_c,Vmid_c)];
    Update=tau*L*VUmid_c*b'+tau*Fmid_c*b';
    VUn=VUn+Update;
    tn=tn+tau
end
Vn_r=VUn(1:N);  Un_r=VUn(N+1:end);

save('reference.mat','Vn_r','Un_r','tn','alpha','beta','ITER_ERR','ITER_COUNT');