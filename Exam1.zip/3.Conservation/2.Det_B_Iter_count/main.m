[time_RRB2,Energy_RRB2,tmesh_RRB2,Iter_count_RRB2,Det_B_RRB2]=RRB(1/200,2);
[time_RRB3,Energy_RRB3,tmesh_RRB3,Iter_count_RRB3,Det_B_RRB3]=RRB(1/200,3);
[time_RRB4,Energy_RRB4,tmesh_RRB4,Iter_count_RRB4,Det_B_RRB4]=RRB(1/200,4);


save('Det_B_Iter_count.mat','time_RRB2','Energy_RRB2','tmesh_RRB2','Iter_count_RRB2','Det_B_RRB2', ...
                            'time_RRB3','Energy_RRB3','tmesh_RRB3','Iter_count_RRB3','Det_B_RRB3', ...
                            'time_RRB4','Energy_RRB4','tmesh_RRB4','Iter_count_RRB4','Det_B_RRB4');