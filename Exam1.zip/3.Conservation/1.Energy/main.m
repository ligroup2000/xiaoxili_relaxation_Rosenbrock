[time_RRB2,Energy_RRB2,tmesh_RRB2]=RRB(1/200,2);
k=1
[time_RRB3,Energy_RRB3,tmesh_RRB3]=RRB(1/200,3);
k=2
[time_RRB4,Energy_RRB4,tmesh_RRB4]=RRB(1/200,4);
k=3
[time_RB2,Energy_RB2,tmesh_RB2]=RB(1/200,2);
k=4
[time_RB3,Energy_RB3,tmesh_RB3]=RB(1/200,3);
k=5
[time_RB4,Energy_RB4,tmesh_RB4]=RB(1/200,4);
k=6


save('data.mat','time_RRB2','Energy_RRB2','tmesh_RRB2', ...
                'time_RRB3','Energy_RRB3','tmesh_RRB3', ...
                'time_RRB4','Energy_RRB4','tmesh_RRB4', ...
                'time_RB2','Energy_RB2','tmesh_RB2', ...
                'time_RB3','Energy_RB3','tmesh_RB3', ...
                'time_RB4','Energy_RB4','tmesh_RB4');