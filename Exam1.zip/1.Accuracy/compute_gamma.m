function [gamma,iter_count,iter_err,vector]=compute_gamma(Vn,Un,Vn_Update,Un_Update,UpdateUpdate,OldUpdate,h,func_F,Nolinear_old,func_f)

iter_err=1;  iter_count=0;  gamma=1;
while ((iter_err>10^(-14)) && (iter_count<5))
    Vn1=Vn+gamma*Vn_Update;  Un1=Un+gamma*Un_Update;  sVUn1=Vn1.^2+Un1.^2;
    vector=gamma^2*UpdateUpdate+2*gamma*OldUpdate-h*sum(func_F(sVUn1))-Nolinear_old;
    matrix=2*gamma*UpdateUpdate+2*OldUpdate-2*h*sum(func_f(sVUn1).*(Vn1.*Vn_Update+Un1.*Un_Update));
    gamma_save=gamma;  gamma=gamma-matrix\vector;
    iter_err=abs(gamma_save-gamma);  iter_count=iter_count+1;
end