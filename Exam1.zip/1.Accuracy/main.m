stepsize=[1/80 1/160 1/320 1/640 1/1280 1/2560 1/5120];
%%%% p=2 %%%%
ERR2=[];  GAMMA_AVE2=[];  S_AVE2=[];
for k=1:size(stepsize,2)
    tau=stepsize(k);
    [err,gamma_ave,S_ave]=RRB(tau,2);
    ERR2=[ERR2 err];
    GAMMA_AVE2=[GAMMA_AVE2 gamma_ave];
    S_AVE2=[S_AVE2 S_ave];
end
Err_Order2=log(ERR2(1:end-1)./ERR2(2:end))./log(stepsize(1:end-1)./stepsize(2:end));
GAMMA_Order2=log(GAMMA_AVE2(1:end-1)./GAMMA_AVE2(2:end))./log(stepsize(1:end-1)./stepsize(2:end));
S_Order2=log(S_AVE2(1:end-1)./S_AVE2(2:end))./log(stepsize(1:end-1)./stepsize(2:end));
%%% p=3 %%%%
ERR3=[];  GAMMA_AVE3=[];  S_AVE3=[];
for k=1:size(stepsize,2)
    tau=stepsize(k);
    [err,gamma_ave,S_ave]=RRB(tau,3);
    ERR3=[ERR3 err];
    GAMMA_AVE3=[GAMMA_AVE3 gamma_ave];
    S_AVE3=[S_AVE3 S_ave];
end
Err_Order3=log(ERR3(1:end-1)./ERR3(2:end))./log(stepsize(1:end-1)./stepsize(2:end));
GAMMA_Order3=log(GAMMA_AVE3(1:end-1)./GAMMA_AVE3(2:end))./log(stepsize(1:end-1)./stepsize(2:end));
S_Order3=log(S_AVE3(1:end-1)./S_AVE3(2:end))./log(stepsize(1:end-1)./stepsize(2:end));
%%%% p=4 %%%%
ERR4=[];  GAMMA_AVE4=[];  S_AVE4=[];
for k=1:size(stepsize,2)
    tau=stepsize(k);
    [err,gamma_ave,S_ave]=RRB(tau,4);
    ERR4=[ERR4 err];
    GAMMA_AVE4=[GAMMA_AVE4 gamma_ave];
    S_AVE4=[S_AVE4 S_ave];
end
Err_Order4=log(ERR4(1:end-1)./ERR4(2:end))./log(stepsize(1:end-1)./stepsize(2:end));
GAMMA_Order4=log(GAMMA_AVE4(1:end-1)./GAMMA_AVE4(2:end))./log(stepsize(1:end-1)./stepsize(2:end));
S_Order4=log(S_AVE4(1:end-1)./S_AVE4(2:end))./log(stepsize(1:end-1)./stepsize(2:end));

save('RRB.mat','ERR2','GAMMA_AVE2','S_AVE2','Err_Order2','GAMMA_Order2','S_Order2', ...
               'ERR3','GAMMA_AVE3','S_AVE3','Err_Order3','GAMMA_Order3','S_Order3', ...
               'ERR4','GAMMA_AVE4','S_AVE4','Err_Order4','GAMMA_Order4','S_Order4');