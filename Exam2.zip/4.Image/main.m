[Un_save,tn_save,XMESH,YMESH]=RRB_initial3(1/10,4);
save('Initial3.mat','Un_save','tn_save','XMESH','YMESH');