for k=1:size(DET_B,1)
    plot(DET_B(k,:));  hold on;
end