function [time,err,energy_err]=csRK4(tau)

tic;  
T=1;  left=-7;  right=7;  N=40;  h=(right-left)/N;  
xmesh=left+0.5*h:h:right-0.5*h;  ymesh=xmesh;  [XMESH,YMESH]=meshgrid(xmesh,ymesh); 
KK=spdiags(ones(N,1),1,N,N)+spdiags(ones(N,1),-1,N,N);  K=kron(KK,speye(N))+kron(speye(N),KK);  
d=size(K,2);  K=K+(-1)*spdiags(sum(K,2),0,d,d);  K=(1/h/h)*K;  
Id=speye(d);  I4d=speye(4*d);  odd=sparse(d,d);  od=sparse(d,1);  A=[odd K;Id odd]; 
alpha=100;  func_F=@(x)alpha*(-cos(x));  func_f=@(x)alpha*(sin(x));  func_f_der=@(x)alpha*(cos(x));
[coe1,coe2,coe3,coe4,coe5,coe6,GW]=generate_coefficient;

tn=0;  Vn=zeros(d,1);  Un_temp=4*atan(exp(3-sqrt(XMESH.^2+YMESH.^2)));  Un=Un_temp(:);  
Energy=0.5*h*h*(Vn'*Vn-Un'*K*Un)+h*h*sum(func_F(Un));
VUn=[Vn;Un];  VUVUn=[VUn;VUn];
while (tn<(T-0.5*tau))
    iter_err=1;  iter_count=0;  Yn=A*VUn;  VUVUn1=VUVUn;  
    while ((iter_err>10^(-14)) && iter_count < 5)
        VUm=VUVUn1(1:2*d);  VUn1=VUVUn1(2*d+1:end);
        Ym=A*VUm;  Yn1=A*VUn1;  Lm=coe5(1)*Yn+coe5(2)*Ym+coe5(3)*Yn1;  Ln1=coe6(1)*Yn+coe6(2)*Ym+coe6(3)*Yn1;
        X1=coe1(1)*VUn+coe2(1)*VUm+coe3(1)*VUn1;  
        X2=coe1(2)*VUn+coe2(2)*VUm+coe3(2)*VUn1;
        X3=coe1(3)*VUn+coe2(3)*VUm+coe3(3)*VUn1;  
        X4=coe1(4)*VUn+coe2(4)*VUm+coe3(4)*VUn1;
        X5=coe1(5)*VUn+coe2(5)*VUm+coe3(5)*VUn1;
        U1=X1(d+1:end); 
        U2=X2(d+1:end);
        U3=X3(d+1:end);
        U4=X4(d+1:end);
        U5=X5(d+1:end);
        F1=[-func_f(U1);od];  
        F2=[-func_f(U2);od];  
        F3=[-func_f(U3);od];
        F4=[-func_f(U4);od];
        F5=[-func_f(U5);od];
        Fm=coe4(1)*F1+coe4(2)*F2+coe4(3)*F3+coe4(4)*F4+coe4(5)*F5;  
        Fn1=GW(1)*F1+GW(2)*F2+GW(3)*F3+GW(4)*F4+GW(5)*F5; 
        Vector=VUVUn1-[VUn;VUn]-tau*[Lm;Ln1]-tau*[Fm;Fn1];
        F1_der=[[odd -spdiags(func_f_der(U1),0,d,d)];[odd odd]]; 
        F2_der=[[odd -spdiags(func_f_der(U2),0,d,d)];[odd odd]];
        F3_der=[[odd -spdiags(func_f_der(U3),0,d,d)];[odd odd]];
        F4_der=[[odd -spdiags(func_f_der(U4),0,d,d)];[odd odd]];
        F5_der=[[odd -spdiags(func_f_der(U5),0,d,d)];[odd odd]];
        Fm_VUm=coe2(1)*coe4(1)*F1_der+coe2(2)*coe4(2)*F2_der+coe2(3)*coe4(3)*F3_der+coe2(4)*coe4(4)*F4_der+coe2(5)*coe4(5)*F5_der;
        Fm_VUn1=coe3(1)*coe4(1)*F1_der+coe3(2)*coe4(2)*F2_der+coe3(3)*coe4(3)*F3_der+coe3(4)*coe4(4)*F4_der+coe3(5)*coe4(5)*F5_der;
        Fn1_VUm=coe2(1)*GW(1)*F1_der+coe2(2)*GW(2)*F2_der+coe2(3)*GW(3)*F3_der+coe2(4)*GW(4)*F4_der+coe2(5)*GW(5)*F5_der;
        Fn1_VUn1=coe3(1)*GW(1)*F1_der+coe3(2)*GW(2)*F2_der+coe3(3)*GW(3)*F3_der+coe3(4)*GW(4)*F4_der+coe3(5)*GW(5)*F5_der;
        Matrix=I4d-tau*[coe5(2)*A coe5(3)*A;coe6(2)*A coe6(3)*A]-tau*[Fm_VUm Fm_VUn1; Fn1_VUm Fn1_VUn1];
        VUVUn1_save=VUVUn1;  VUVUn1=VUVUn1-Matrix\Vector;
        iter_err=max(abs(VUVUn1_save-VUVUn1));
        iter_count=iter_count+1;
    end
    VUVUn=VUVUn1;  VUn=VUVUn1(2*d+1:end,1);  tn=tn+tau;
    Vn=VUn(1:d,1);  Un=VUn(d+1:end,1);  Energy=[Energy 0.5*h*h*(Vn'*Vn-Un'*K*Un)+h*h*sum(func_F(Un))];
end
toc;

time=toc;
load('reference.mat');  
err=max(abs([Vn;Un]-[Vn_r;Un_r]));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));