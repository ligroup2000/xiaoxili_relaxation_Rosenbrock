function [time,err,energy_err]=csERK4(tau)
tic;  
T=1;  left=-7;  right=7;  N=40;  h=(right-left)/N;  
xmesh=left+0.5*h:h:right-0.5*h;  ymesh=xmesh;  [XMESH,YMESH]=meshgrid(xmesh,ymesh); 
KK=spdiags(ones(N,1),1,N,N)+spdiags(ones(N,1),-1,N,N);  K=kron(KK,speye(N))+kron(speye(N),KK);  
d=size(K,2);  K=K+(-1)*spdiags(sum(K,2),0,d,d);  K=(1/h/h)*K;  
Id=speye(d);  I4d=speye(4*d);  odd=sparse(d,d);  od=sparse(d,1);  A=[odd K;Id odd]; 
alpha=100;  func_F=@(x)alpha*(-cos(x));  func_f=@(x)alpha*(sin(x));  func_f_der=@(x)alpha*(cos(x));
[coe1,coe2,coe3,AA1,AA2,AA3,AA4,AA5,BB1,BB2,BB3,BB4,BB5,e5,e6]=generate_coefficient(tau,A);

tn=0;  Vn=zeros(d,1);  Un_temp=4*atan(exp(3-sqrt(XMESH.^2+YMESH.^2)));  Un=Un_temp(:);  
Energy=0.5*h*h*(Vn'*Vn-Un'*K*Un)+h*h*sum(func_F(Un));
VUn=[Vn;Un];  VUVUn=[VUn;VUn];  
while (tn<(T-0.5*tau))
    iter_err=1;  iter_count=0;  KK=[e5*VUn;e6*VUn];  VUVUn1=VUVUn;  
    while ((iter_err>10^(-14)) && iter_count < 5)
        VUm=VUVUn1(1:2*d);  VUn1=VUVUn1(2*d+1:end);
        X1=coe1(1)*VUn+coe2(1)*VUm+coe3(1)*VUn1;  X2=coe1(2)*VUn+coe2(2)*VUm+coe3(2)*VUn1;
        X3=coe1(3)*VUn+coe2(3)*VUm+coe3(3)*VUn1;  X4=coe1(4)*VUn+coe2(4)*VUm+coe3(4)*VUn1;
        X5=coe1(5)*VUn+coe2(5)*VUm+coe3(5)*VUn1;
        U1=X1(d+1:end); 
        U2=X2(d+1:end);
        U3=X3(d+1:end);
        U4=X4(d+1:end);
        U5=X5(d+1:end);
        F1=[-func_f(U1);od];  
        F2=[-func_f(U2);od];   
        F3=[-func_f(U3);od];  
        F4=[-func_f(U4);od];  
        FF5=[-func_f(U5);od];  
        Fm=AA1*F1+AA2*F2+AA3*F3+AA4*F4+AA5*FF5;  
        Fn1=BB1*F1+BB2*F2+BB3*F3+BB4*F4+BB5*FF5; 
        Vector=VUVUn1-KK-tau*[Fm;Fn1];  
        F1_der=[[odd -spdiags(func_f_der(U1),0,d,d)];[odd odd]];  
        F2_der=[[odd -spdiags(func_f_der(U2),0,d,d)];[odd odd]];
        F3_der=[[odd -spdiags(func_f_der(U3),0,d,d)];[odd odd]];
        F4_der=[[odd -spdiags(func_f_der(U4),0,d,d)];[odd odd]];
        F5_der=[[odd -spdiags(func_f_der(U5),0,d,d)];[odd odd]];
        Fm_VUm=coe2(1)*AA1*F1_der+coe2(2)*AA2*F2_der+coe2(3)*AA3*F3_der+coe2(4)*AA4*F4_der+coe2(5)*AA5*F5_der;
        Fm_VUn1=coe3(1)*AA1*F1_der+coe3(2)*AA2*F2_der+coe3(3)*AA3*F3_der+coe3(4)*AA4*F4_der+coe3(5)*AA5*F5_der;
        Fn1_VUm=coe2(1)*BB1*F1_der+coe2(2)*BB2*F2_der+coe2(3)*BB3*F3_der+coe2(4)*BB4*F4_der+coe2(5)*BB5*F5_der;
        Fn1_VUn1=coe3(1)*BB1*F1_der+coe3(2)*BB2*F2_der+coe3(3)*BB3*F3_der+coe3(4)*BB4*F4_der+coe3(5)*BB5*F5_der;
        Matrix=I4d-tau*[Fm_VUm Fm_VUn1; Fn1_VUm Fn1_VUn1];
        VUVUn1_save=VUVUn1;  VUVUn1=VUVUn1-Matrix\Vector;
        iter_err=max(abs(VUVUn1_save-VUVUn1));
        iter_count=iter_count+1;
    end
    VUVUn=VUVUn1;  VUn=VUVUn1(2*d+1:end,1);  tn=tn+tau;  
    Vn=VUn(1:d,1);  Un=VUn(d+1:end,1);  Energy=[Energy 0.5*h*h*(Vn'*Vn-Un'*K*Un)+h*h*sum(func_F(Un))];
end
toc;

time=toc;
load('reference.mat');  
err=max(abs([Vn;Un]-[Vn_r;Un_r]));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));