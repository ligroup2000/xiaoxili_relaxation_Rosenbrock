function [time,err,energy_err]=AVF(tau)

tic;  
T=1;  left=-7;  right=7;  N=40;  h=(right-left)/N;  
xmesh=left+0.5*h:h:right-0.5*h;  ymesh=xmesh;  [XMESH,YMESH]=meshgrid(xmesh,ymesh); 
KK=spdiags(ones(N,1),1,N,N)+spdiags(ones(N,1),-1,N,N);  K=kron(KK,speye(N))+kron(speye(N),KK);  
d=size(K,2);  K=K+(-1)*spdiags(sum(K,2),0,d,d);  K=(1/h/h)*K;  
Id=speye(d);  I2d=speye(2*d);  odd=sparse(d,d);  od=sparse(d,1);  A=[odd K;Id odd]; 
alpha=100;  func_F=@(x)alpha*(-cos(x));  func_f=@(x)alpha*(sin(x));  func_f_der=@(x)alpha*(cos(x));
[GP,GW]=generate_GP_GW;

tn=0;  Vn=zeros(d,1);  Un_temp=4*atan(exp(3-sqrt(XMESH.^2+YMESH.^2)));  Un=Un_temp(:);  
Energy=0.5*h*h*(Vn'*Vn-Un'*K*Un)+h*h*sum(func_F(Un));
VUn=[Vn;Un];
while (tn<(T-0.5*tau))
    iter_err=1;  iter_count=0;  VUn1=VUn;  Un=VUn(d+1:end,1);  
    while ((iter_err>10^(-14)) && iter_count < 5)
        Un1=VUn1(d+1:end,1);  dU=Un1-Un;
        U1=Un+GP(1)*dU;  U2=Un+GP(2)*dU;  U3=Un+GP(3)*dU;  U4=Un+GP(4)*dU;  U5=Un+GP(5)*dU;
        FV=GW(1)*func_f(U1)+GW(2)*func_f(U2)+GW(3)*func_f(U3)+GW(4)*func_f(U4)+GW(5)*func_f(U5);
        Vector=VUn1-VUn-0.5*tau*A*(VUn1+VUn)-tau*[-FV;od];
        FV_der=GW(1)*GP(1)*func_f_der(U1)+GW(2)*GP(2)*func_f_der(U2)+GW(3)*GP(3)*func_f_der(U3)+GW(4)*GP(4)*func_f_der(U4)+GW(5)*GP(5)*func_f_der(U5);
        Matrix=I2d-0.5*tau*A-tau*[[odd -spdiags(FV_der,0,d,d)];[odd odd]];
        VUn1_save=VUn1;
        VUn1=VUn1-Matrix\Vector;
        iter_err=max(abs(VUn1_save-VUn1));
        iter_count=iter_count+1;
    end
    VUn=VUn1;  tn=tn+tau;
    Vn=VUn(1:d);  Un=VUn(d+1:end);  Energy=[Energy 0.5*h*h*(Vn'*Vn-Un'*K*Un)+h*h*sum(func_F(Un))];
end
toc;

time=toc;
load('reference.mat');  
err=max(abs([Vn;Un]-[Vn_r;Un_r]));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));