function [time,err,energy_err]=RERB2(tau)
tic; 

T=1;  left=-7;  right=7;  N=40;  h=(right-left)/N;  
xmesh=left+0.5*h:h:right-0.5*h;  ymesh=xmesh;  [XMESH,YMESH]=meshgrid(xmesh,ymesh); 
KK=spdiags(ones(N,1),1,N,N)+spdiags(ones(N,1),-1,N,N);  K=kron(KK,speye(N))+kron(speye(N),KK);  
d=size(K,2);  K=K+(-1)*spdiags(sum(K,2),0,d,d);  K=(1/h/h)*K;  
Id=speye(d);  I1=speye(2*d+1);  odd=sparse(d,d);  od=sparse(d,1);  o2d=sparse(1,2*d);  A=[odd K;Id odd]; 
alpha=100;  func_F=@(x)alpha*(-cos(x));  func_f=@(x)alpha*(sin(x));  func_f_der=@(x)alpha*(cos(x));

tn=0;  Vn=zeros(d,1);  Un_temp=4*atan(exp(3-sqrt(XMESH.^2+YMESH.^2)));  Un=Un_temp(:);  
Energy=0.5*h*h*(Vn'*Vn-Un'*K*Un)+h*h*sum(func_F(Un));
while (tn<(T-tau))
    pGpUn=[odd -spdiags(func_f_der(Un),0,d,d);odd odd];  Jn=A+pGpUn;  
    G=[-func_f(Un);od];  F=A*[Vn;Un]+G;
    Matrix=tau*[Jn F; o2d 0];
    exp_matrix=expm(Matrix);
    Vn_Update=exp_matrix(1:d,end);  Un_Update=exp_matrix(d+1:2*d,end);  
    Update_norm=sum(abs(Vn_Update).^2)+sum(abs(Un_Update).^2);
    if ( Update_norm==0 )
        gamma=1;
    else
        UpdateUpdate=0.5*h*h*(Vn_Update'*Vn_Update-Un_Update'*K*Un_Update);
        OldUpdate=0.5*h*h*(Vn'*Vn_Update-Un'*K*Un_Update);
        Nolinear_old=h*h*sum(func_F(Un));
        [gamma,~,~,~]=compute_gamma(Un,Un_Update,UpdateUpdate,OldUpdate,h,func_F,Nolinear_old,func_f);
    end
    Vn_save=Vn;  Un_save=Un;  tn_save=tn;
    Vn=Vn+gamma*Vn_Update;  Un=Un+gamma*Un_Update;  tn=tn+gamma*tau;
    Energy=[Energy 0.5*h*h*(Vn'*Vn-Un'*K*Un)+h*h*sum(func_F(Un))];
end

if ( (T-tn)<=0 )  
    Un=Un_save;  Vn=Vn_save;  tn=tn_save;  tau=T-tn;
else
    tau=T-tn;
end
pGpUn=[odd -spdiags(func_f_der(Un),0,d,d);odd odd];  Jn=A+pGpUn;  
G=[-func_f(Un);od];  F=A*[Vn;Un]+G;
Matrix=tau*[Jn F; o2d 0];
exp_matrix=expm(Matrix);
Vn=Vn+exp_matrix(1:d,end);  Un=Un+exp_matrix(d+1:2*d,end);  tn=tn+tau;
toc;

time=toc;
load('reference.mat');  
err=max(abs([Vn;Un]-[Vn_r;Un_r]));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));