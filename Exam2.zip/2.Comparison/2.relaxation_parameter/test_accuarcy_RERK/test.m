stepsize=[1/10 1/20 1/40 1/80 1/160 1/320 1/640];

ERR=[];  GAMMA=[];
for k=1:size(stepsize,2)
    [err,gamma_ave]=RERK2(stepsize(k));
    ERR=[ERR err];
    GAMMA=[GAMMA gamma_ave];
end

ERR
ERR_order=log(ERR(1:end-1)./ERR(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
GAMMA
GAMMA_order=log(GAMMA(1:end-1)./GAMMA(2:end))./log(stepsize(1:end-1)./stepsize(2:end))