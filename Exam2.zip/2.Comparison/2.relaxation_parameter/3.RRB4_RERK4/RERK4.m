function [Gamma,tmesh]=RERK4(tau)

w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
   w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
   w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
   w1+w5 w11+w3+w44 w11+w3-w44 w1];
b=[2*w1 2*w11 2*w11 2*w1];
c=[0.5-w2; 0.5-w22; 0.5+w22; 0.5+w2];

T=1;  left=-7;  right=7;  N=40;  h=(right-left)/N;  
xmesh=left+0.5*h:h:right-0.5*h;  ymesh=xmesh;  [XMESH,YMESH]=meshgrid(xmesh,ymesh); 
KK=spdiags(ones(N,1),1,N,N)+spdiags(ones(N,1),-1,N,N);  K=kron(KK,speye(N))+kron(speye(N),KK);  
d=size(K,2);  K=K+(-1)*spdiags(sum(K,2),0,d,d);  K=(1/h/h)*K;  s=size(A,1);
L=[sparse(d,d) K;speye(d) sparse(d,d)];  Matrix=speye(2*d*s)-tau*kron(A,L);  
es=ones(s,1);
alpha=10000;  func_F=@(x)alpha*(-cos(x));  func_f=@(x)alpha*(sin(x)); 

t=0;  Vn=zeros(d,1);  Un_temp=4*atan(exp(3-sqrt(XMESH.^2+YMESH.^2)));  Un=Un_temp(:);  Xn=[Vn;Un];  
Gamma=[];  tmesh=t;

Iter_err=1;  ccout=0;  Xmid=kron(es,Xn); 
while (Iter_err > 10^(-14) && ccout < 100)
    Xmid_c=reshape(Xmid,2*d,s);  fmid_c=-func_f(Xmid_c(d+1:2*d,:));  Fmid_c=[fmid_c; sparse(d,s)];
    F=Xn+tau*Fmid_c*A';
    Xmid_save=Xmid;  Xmid=Matrix\F(:);
    Iter_err=max(abs(Xmid-Xmid_save));
    ccout=ccout+1;
end
Xmid_c=reshape(Xmid,2*d,s);  fmid_c=-func_f(Xmid_c(d+1:2*d,:));  Fmid_c=[fmid_c; sparse(d,s)];
Update=tau*L*Xmid_c*b'+tau*Fmid_c*b';  Vn_Update=Update(1:d);  Un_Update=Update(d+1:end);
Update_norm=sum(abs(Vn_Update).^2)+sum(abs(Un_Update).^2);
if ( Update_norm==0 )
    gamma=1;
else
    UpdateUpdate=0.5*h*h*(Vn_Update'*Vn_Update-Un_Update'*K*Un_Update);
    OldUpdate=0.5*h*h*(Vn'*Vn_Update-Un'*K*Un_Update);
    Nolinear_old=h*h*sum(func_F(Un));
    [gamma,~,~,~]=compute_gamma(Un,Un_Update,UpdateUpdate,OldUpdate,h,func_F,Nolinear_old,func_f);
end
Xn=Xn+gamma*Update;  Vn=Xn(1:d);  Un=Xn(d+1:end);
t1=t;
t=t+gamma*tau;
t2=t; 
tmesh=[tmesh t2];  Gamma=[Gamma gamma];
fprintf('t=%d,dis=%d\n',t2,abs(gamma-1));

for k=1:99
    coe=extrapolate_coe(t1,t2,c,tau,tau);  Xmid_e_c=Xmid_c*coe';
    fmid_e_c=-func_f(Xmid_e_c(d+1:2*d,:));  Fmid_e_c=[fmid_e_c; sparse(d,s)];
    F=Xn+tau*Fmid_e_c*A';
    Xmid=Matrix\F(:);  Xmid_c=reshape(Xmid,2*d,s);
    Update=tau*L*Xmid_c*b'+tau*Fmid_e_c*b';  Vn_Update=Update(1:d);  Un_Update=Update(d+1:end);
    Update_norm=sum(abs(Vn_Update).^2)+sum(abs(Un_Update).^2);
    if ( Update_norm==0 )
        gamma=1;
    else
        UpdateUpdate=0.5*h*h*(Vn_Update'*Vn_Update-Un_Update'*K*Un_Update);
        OldUpdate=0.5*h*h*(Vn'*Vn_Update-Un'*K*Un_Update);
        Nolinear_old=h*h*sum(func_F(Un));
        [gamma,~,~,~]=compute_gamma(Un,Un_Update,UpdateUpdate,OldUpdate,h,func_F,Nolinear_old,func_f);
    end
    Xn=Xn+gamma*Update;  Vn=Xn(1:d);  Un=Xn(d+1:end);
    t1=t;
    t=t+gamma*tau;
    t2=t; 
    tmesh=[tmesh t2];  Gamma=[Gamma gamma];
    fprintf('t=%d,dis=%d\n',t2,abs(gamma-1));
end

plot(Gamma)