w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
   w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
   w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
   w1+w5 w11+w3+w44 w11+w3-w44 w1];
b=[2*w1 2*w11 2*w11 2*w1];

T=1;  tau=1/1000;  alpha=100;
left=-7;  right=7;  N=40;  h=(right-left)/N;  
xmesh=left+0.5*h:h:right-0.5*h;  ymesh=xmesh;  [XMESH,YMESH]=meshgrid(xmesh,ymesh); 
KK=spdiags(ones(N,1),1,N,N)+spdiags(ones(N,1),-1,N,N);  K=kron(KK,speye(N))+kron(speye(N),KK);  
d=size(K,2);  K=K+(-1)*spdiags(sum(K,2),0,d,d);  K=(1/h/h)*K;
L=[sparse(d,d) K;speye(d) sparse(d,d)];  s=size(A,1);  es=ones(s,1);  Id=speye(2*d);  ess=es';
Matrix=(speye(2*d*s)-tau*kron(A,L))^(-1);  o=sparse(d,d);
func_f=@(x)(-alpha)*(sin(x));  func_f_der=@(x)(-alpha)*(cos(x));
t=0;  Vn=zeros(d,1);  Un_temp=4*atan(exp(3-sqrt(XMESH.^2+YMESH.^2)));  Un=Un_temp(:);  Xn=[Vn; Un];  

Jn=sparse(2*d*s,2*d*s);  ITER_ERR=[];  ITER_COUNT=[];
for k=1:round(T/tau)
    Iter_err=1;  Iter_count=0;  Xmid=kron(es,Xn);
    while (Iter_err > 10^(-14) && Iter_count < 100)
        Xmid_c=reshape(Xmid,2*d,s);  fmid_c=func_f(Xmid_c(d+1:2*d,:));  Fmid_c=[fmid_c; sparse(d,s)];
        F=kron(ess,Xn)+tau*Fmid_c*A';
        Xmid_save=Xmid;  Xmid=Matrix*F(:);
        Iter_err=max(abs(Xmid-Xmid_save));
        Iter_count=Iter_count+1;
    end
    ITER_ERR=[ITER_ERR Iter_err];  ITER_COUNT=[ITER_COUNT Iter_count];
    Xmid_c=reshape(Xmid,2*d,s);  fmid_c=func_f(Xmid_c(d+1:2*d,:));  Fmid_c=[fmid_c; sparse(d,s)];
    Update=tau*L*Xmid_c*b'+tau*Fmid_c*b';
    Xn=Xn+Update;
    t=t+tau;
end
Vn_r=Xn(1:d);  Un_r=Xn(d+1:2*d);

save('reference.mat','Vn_r','Un_r','t','alpha','ITER_ERR','ITER_COUNT');